package ejbs;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;

/**
 * Session Bean implementation class calculate
 */
@Stateless
@LocalBean
public class Calculate {

    public int getresult(int number1,int number2,String operation) {
    	if(operation=="+") {
    		return number1+number2;
    	}
    	else if(operation=="-") {
    		return number1-number2;
    	}
    	else if(operation=="/") {
    		return number1/number2;
    	}
    	else if(operation=="*") {
    		return number1*number2;
    	}
    	else {
    		return 0;
    	}
    }

}
