package webService;

import javax.ejb.EJB;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.ws.rs.Consumes;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import database.Calculation;
import ejbs.Calculate;

@Stateless
@Produces(MediaType.APPLICATION_JSON)
@Consumes(MediaType.APPLICATION_JSON)
public class service {

	@PersistenceContext(unitName="hello")
	private EntityManager entityManager;
	
	@EJB
	Calculate calc;
	
	@EJB
	Calculation instance;
	
	@Path("/calc")
	@POST
	public int Createcalc(int number1,int number2,String operation) {
		int res=calc.getresult(number1,number2,operation);
		instance.setNumber1(number1);
		instance.setNumber2(number2);
		instance.setOperation(operation);
		instance.setresult(res);
		entityManager.persist(instance);
		return res;
	}
	
	@Path("/calculations")
	@GET
    public Calculation GetCalculations() {
		return entityManager.find(null,Calculation.class);
    }
	
	
}
