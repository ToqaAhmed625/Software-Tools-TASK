package database;

import javax.ejb.Stateless;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Stateless
@Entity
public class Calculation {

	@Id
	@GeneratedValue(strategy=GenerationType.IDENTITY)
	int operationNum;
	int Number1;
	int Number2;
	String Operation;
	int result;
	
	public void setNumber1(int Number1) {
		this.Number1=Number1;
	}
	
	public int getNumber1() {
		return Number1;
	}
	
	public void setNumber2(int Number2) {
		this.Number2=Number2;
	}
	
	public int getNumber2() {
		return Number2;
	}
	
	public void setOperation(String Operation) {
		this.Operation=Operation;
	}
	
	public String getOperation() {
		return Operation;
	}
	
	public void setresult(int result) {
		this.result=result;
	}
	
	public int getresult() {
		return result;
	}
	
}
